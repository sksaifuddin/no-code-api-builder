exports.handler = async (event, context) => {
  try {
    console.log("Received event:", JSON.stringify(event));
    // Do your custom resource logic here, e.g., execute SQL queries, etc.
    
    // Simulate a successful operation (you should replace this with your actual logic)
    const responseData = {
      Message: "Custom resource operation completed successfully",
      Data: {
        Key1: "Value1",
        Key2: "Value2",
      },
    };
    
    const response = {
      Status: "SUCCESS",
      PhysicalResourceId: event.PhysicalResourceId,
      StackId: event.StackId,
      RequestId: event.RequestId,
      LogicalResourceId: event.LogicalResourceId,
      Data: responseData,
    };
    
    console.log("Sending response:", JSON.stringify(response));
    return response;
  } catch (error) {
    console.error("Error occurred:", error);
    const response = {
      Status: "FAILED",
      PhysicalResourceId: event.PhysicalResourceId,
      StackId: event.StackId,
      RequestId: event.RequestId,
      LogicalResourceId: event.LogicalResourceId,
    };
    
    console.log("Sending response:", JSON.stringify(response));
    return response;
  }
};
